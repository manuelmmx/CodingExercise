﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercise
{
    public class FileUtility
    {
        /// <summary>
        /// Download a file from url and save into disk. 
        /// </summary>
        /// <param name="uri">File where to download the file</param>
        /// <param name="outputPath">Local path where the file will be saved.</param>
        /// <returns></returns>
        public static async Task DownloadFileAsync(string url, string outputPath)
        {
            try
            {
                HttpClient _httpClient = new HttpClient();
                Uri uriResult;

                if (!Uri.TryCreate(url, UriKind.Absolute, out uriResult))
                    throw new InvalidOperationException("URI is invalid.");

                if (File.Exists(outputPath))
                {
                    File.Delete(outputPath); //Get always the latest file.
                }

                byte[] fileBytes = await _httpClient.GetByteArrayAsync(url);
                File.WriteAllBytes(outputPath, fileBytes);
            }
            catch (Exception ex)
            {
                //We should log it. At least we will throw an exception with espeficics.
                throw new Exception("An error ocurred while downloading data file.", ex);
            }
        }

        public static string[] GetRawRecords (string filePath)
        {
            return File.ReadAllLines(filePath);
        }
    }
}
