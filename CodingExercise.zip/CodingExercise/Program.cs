﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercise
{
    class Program
    {
        static async Task Main(string[] args)
        {
            try
            {
                var configuration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

                string _fileUrl = configuration["FileURL"];
                string _filePath = configuration["FilePath"];
                string _taxUrl = configuration["TaxUrl"];

                if (_fileUrl is null || _filePath is null || _taxUrl is null)
                {
                    Console.WriteLine("Configuration settings are missing. Please add them.");
                    return;
                }

                //Use a utilit file to encapsulate File object use
                await FileUtility.DownloadFileAsync(_fileUrl, _filePath);

                var allRecords = FileUtility.GetRawRecords(_filePath);
                Console.WriteLine("******************************** Raw Records Display *********************************************************");
                Console.WriteLine(Environment.NewLine);
                DisplayRowsRecordsOnScreen(allRecords);

                var allLocations = await PropertyManager.GetPropertiesFromRawRecords(allRecords, _taxUrl);
                Console.WriteLine("******************************** Property objects Display *********************************************************");
                Console.WriteLine(Environment.NewLine);
                DisplayObjectsOnScreen(allLocations);

                string propertyType = "Residential";
                HashSet<Property> biggestPropertiesList = PropertyManager.GetBiggestFlatsPerCityPerType(allLocations, propertyType);

                Console.WriteLine("******************************** Biggest Residential flats per city *********************************************************");
                Console.WriteLine(Environment.NewLine);
                DisplayObjectsOnScreen(biggestPropertiesList);


                var biggestCheaper = PropertyManager.GetCheapestBiggestFlat(allLocations);
                Console.WriteLine("******************************** Cheapest with the most rooms flats *********************************************************");
                Console.WriteLine(Environment.NewLine);
                DisplayOneObjectOnScreen(biggestCheaper);

                var mostExpensive = PropertyManager.GetMostExpensiveOnTotalPriceFlatsPerCity(allLocations);
                Console.WriteLine("******************************** More expensive on total price per city *********************************************************");
                Console.WriteLine(Environment.NewLine);
                DisplayObjectsOnScreen(mostExpensive);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Something went wrong! Please check details \n {ex}");
            }
        }

        private static void DisplayRowsRecordsOnScreen(string[] allRecords)
        {
            foreach (string line in allRecords)
            {
                string[] columns = line.Split(',');
                var rowData = new StringBuilder();

                foreach (string column in columns)
                {
                    rowData.Append( $" {column} |");
                }

                Console.WriteLine(rowData.ToString());
            }
        }

        private static void DisplayObjectsOnScreen(HashSet<Property> allLocations)
        {
            foreach (Property singleLocation in allLocations)
            {
                DisplayOneObjectOnScreen(singleLocation);
            }
        }
        private static void DisplayOneObjectOnScreen(Property singleLocation)
        {

                Console.WriteLine($"{singleLocation.Street} | {singleLocation.City} | {singleLocation.ZipCode} | {singleLocation.State} | " +
                                    $"{singleLocation.Beds} | {singleLocation.Baths} | {singleLocation.SizeInSqFt:N0} | {singleLocation.Type} |" +
                                        $"{singleLocation.SaleDate:f} | {singleLocation.Price:C} | {singleLocation.Latitude} | {singleLocation.Longitude}");
        }

    }
}
