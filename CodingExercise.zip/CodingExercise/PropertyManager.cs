﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercise
{
    public class PropertyManager
    {

        public PropertyManager()
        {

        }


        /// <summary>
        /// Returns a list of the biggest propertyies per city for a given type.
        /// </summary>
        /// <param name="allLocations">List of All properties</param>
        /// <param name="type">Specfic type to look for</param>
        /// <returns>HashSet<Property></returns>
        public static HashSet<Property> GetBiggestFlatsPerCityPerType(HashSet<Property> allLocations, string type)
        {
            //Get Largest sizes per city
            var largestPerCity =
                from loc in allLocations
                where loc.Type.ToLower() == type.ToLower()
                group loc by loc.City into locs
                select new
                {
                    City = locs.Key,
                    SizeInSqFt = locs.Max(locs => locs.SizeInSqFt)
                };

            //Join with whole list to filter out bigger ones
            var finalList = from l in allLocations
                            join m in largestPerCity on
                            new { l.SizeInSqFt, l.City } equals
                            new { m.SizeInSqFt, m.City }
                            select l;

            return finalList.ToHashSet();
        }

        /// <summary>
        /// Returns a list of the biggest flat in sq ft
        /// </summary>
        /// <param name="allLocations"></param>
        /// <returns>HashSet<Property></returns>
        public static Property GetCheapestBiggestFlat(HashSet<Property> allLocations)
        {
            //Get Largest sizes per city
            var moreRooms =
                (from loc in allLocations
                 orderby loc.Price ascending
                 group loc by (loc.Beds + loc.Baths) into locs
                 select new
                 {
                     Rooms = locs.Key,
                     Price = locs.Min(locs => locs.Price)
                 }).FirstOrDefault();

            //Join with whole list to filter out bigger ones
            var finalList = from l in allLocations
                            where (l.Baths + l.Beds) == moreRooms.Rooms && l.Price == moreRooms.Price
                            select l;

            return finalList.FirstOrDefault();
        }

        /// <summary>
        /// Returns a list of most expensive flats based on total price price + price * tax
        /// </summary>
        /// <param name="allLocations"></param>
        /// <returns>HashSet<Property></returns>
        public static HashSet<Property> GetMostExpensiveOnTotalPriceFlatsPerCity(HashSet<Property> allLocations)
        {
            //Get Largest sizes per city
            var mostExpensivePerCity =
                from loc in allLocations
                group loc by loc.City into locs
                select new
                {
                    City = locs.Key,
                    TotalPrice = locs.Max(locs => locs.TotalPrice)
                };

            //Join with whole list to filter out bigger ones
            var finalList = from l in allLocations
                            join m in mostExpensivePerCity on
                            new { l.TotalPrice, l.City } equals
                            new { m.TotalPrice, m.City }
                            select l;

            return finalList.ToHashSet();
        }

        /// <summary>
        /// REturns an list of Properties that are parsed from the array of comma separated record
        /// </summary>
        /// <param name="allRecords">Raw comma sepparated record</param>
        /// <param name="taxUrl">url to get the taxes</param>
        /// <returns>Task<HashSet<Property></returns>
        public static async Task<HashSet<Property>> GetPropertiesFromRawRecords(string[] allRecords, string taxUrl)
        {
            try
            {
                var locations = new HashSet<Property>();

                //for (string line in allRecords)
                for (int i = 1; i < allRecords.Length; i++)
                {
                    var singleLocation = Property.MapFromFileLine(allRecords[i]);
                    locations.Add(singleLocation);
                }

                //We are adding this part here because this tax info will be used lated. 
                var cityWithTaxes = await GetTaxesForUniqueCities(locations, taxUrl);

                AddTaxesToEachProperty(locations, cityWithTaxes);

                return locations;
            }
            catch (Exception ex)
            {
                throw new Exception ("An error ocurred while parsing raw information. Please see error details.", ex);
            }

        }

        private static async Task<Dictionary<string, decimal>> GetTaxesForUniqueCities(HashSet<Property> locations, string taxUrl)
        {
            try
            {
                HttpClient client = new HttpClient();
                var cities = locations.Select(c => c.City).Distinct().ToList();
                var citiesWithTaxes = new Dictionary<string, decimal>();
                foreach (string city in cities)
                {
                    var stringTask = await client.GetStringAsync($"{taxUrl}{city}");
                    decimal outputTax;
                    citiesWithTaxes.Add(city, decimal.TryParse(stringTask, out outputTax) ? outputTax : 0);
                }

                return citiesWithTaxes;
            }
            catch (Exception ex)
            {
                //SHould be logged
                throw new Exception("An error ocurred while getting taxes for properties.", ex);
            }
        }

        private static void AddTaxesToEachProperty(HashSet<Property> allLocations, Dictionary<string, decimal> taxes)
        {
            foreach (Property location in allLocations)
            {
                decimal tax;
                location.Tax = taxes.TryGetValue(location.City, out tax) ? tax : 0;
            }
        }
    }
}
